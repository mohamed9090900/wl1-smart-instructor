import './style.css';
import * as pdfjs from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { retrieve } from './search.js';

pdfjs.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

const MODEL_ID = 'Qwen3-0.6B-q4f16_1-MLC';
const DB_NAME = 'wl1-smart-instructor-local-v1';
const $ = id => document.getElementById(id);
const views = [...document.querySelectorAll('.view')];
const chatHistory = [];
let db;
let engine;
let admin = false;
let referenceUrl = null;
let installPrompt = null;

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const store = request.result.createObjectStore('references', { keyPath: 'id' });
      store.createIndex('name', 'name', { unique: false });
      request.result.createObjectStore('settings', { keyPath: 'key' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function allRefs() {
  return requestResult(db.transaction('references').objectStore('references').getAll());
}
async function saveRef(ref) {
  return requestResult(db.transaction('references', 'readwrite').objectStore('references').put(ref));
}
async function removeRef(id) {
  return requestResult(db.transaction('references', 'readwrite').objectStore('references').delete(id));
}
async function getSetting(key) {
  const row = await requestResult(db.transaction('settings').objectStore('settings').get(key));
  return row?.value;
}
async function saveSetting(key, value) {
  return requestResult(db.transaction('settings', 'readwrite').objectStore('settings').put({ key, value }));
}

function setView(id) {
  views.forEach(view => view.classList.toggle('active', view.id === id));
  document.querySelectorAll('nav [data-target]').forEach(button => button.classList.toggle('active', button.dataset.target === id));
  if (id === 'refs') renderRefs();
}
document.querySelectorAll('nav [data-target]').forEach(button => button.addEventListener('click', () => setView(button.dataset.target)));

function addMessage(text, mine = false, citations = []) {
  const el = document.createElement('div');
  el.className = `msg${mine ? ' mine' : ''}`;
  el.textContent = text;
  if (citations.length) {
    const links = document.createElement('div');
    links.className = 'citations';
    citations.forEach(hit => {
      const link = document.createElement('button');
      link.className = 'citation';
      link.textContent = `${hit.name} · p. ${hit.page}`;
      link.addEventListener('click', () => showReference(hit.refId, hit.page));
      links.append(link);
    });
    el.append(links);
  }
  $('chat').append(el);
  el.scrollIntoView({ block: 'nearest' });
  return el;
}

async function modelReady() {
  if (engine) return engine;
  if (!navigator.gpu) throw new Error('المتصفح الحالي لا يتيح تشغيل النموذج المحلي. افتح التطبيق من Safari محدّث على iPhone أو Chrome محدّث على Android والكمبيوتر.');
  $('modelStart').disabled = true;
  $('modelProgress').classList.remove('hidden');
  $('modelStatus').textContent = 'تحميل النموذج أول مرة إلى مساحة هذا الجهاز...';
  try {
    const { CreateMLCEngine } = await import('@mlc-ai/web-llm');
    engine = await CreateMLCEngine(MODEL_ID, {
      initProgressCallback: progress => {
        const value = Number(progress.progress || 0);
        $('modelProgress').value = Math.max(0, Math.min(1, value));
        $('modelStatus').textContent = progress.text || `تحميل النموذج ${Math.round(value * 100)}٪`;
      },
    });
    $('modelStatus').textContent = 'المدرس المحلي جاهز على هذا الجهاز';
    $('modelStart').textContent = 'النموذج جاهز';
    $('modelProgress').classList.add('hidden');
    return engine;
  } catch (error) {
    $('modelStatus').textContent = 'تعذر تشغيل النموذج. جرّب متصفحًا محدّثًا أو حرّر مساحة على الجهاز.';
    $('modelProgress').classList.add('hidden');
    throw error;
  } finally {
    $('modelStart').disabled = false;
  }
}

function requestOptions(messages, maxTokens = 320) {
  return { messages, temperature: 0.7, top_p: 0.8, max_tokens: maxTokens, enable_thinking: false };
}

async function englishSearchQuery(question) {
  const response = await engine.chat.completions.create(requestOptions([
    { role: 'system', content: 'Translate the user question into 3 to 8 concise English search keywords for a technical manual. Output only keywords. Do not answer or add facts.' },
    { role: 'user', content: question },
  ], 40));
  return response.choices?.[0]?.message?.content?.replace(/<think>[\s\S]*?<\/think>/g, '').trim() || '';
}

async function answerQuestion(question, priorHits) {
  const refs = await allRefs();
  const followUp = question.length < 65 && /مش\s*فاهم|اشرح\s*(تاني|كمان)|وضح|ليه|why|explain\s*again/i.test(question);
  let hits = followUp ? priorHits : [];
  if (!hits.length) {
    let searchQuery = question;
    if (/[\u0600-\u06ff]/.test(question)) {
      const translated = await englishSearchQuery(question);
      if (translated) searchQuery = `${question} ${translated}`;
    }
    hits = retrieve(searchQuery, refs);
  }
  if (!hits.length) return { text: 'مش لاقي في نصوص المراجع النشطة ما يدعم الإجابة. جرّب صياغة تانية أو أضف المرجع المطلوب.', hits: [] };

  const sourceText = hits.map((hit, index) => `[${index + 1}] ${hit.name}, page ${hit.page}\n${hit.text}`).join('\n\n');
  const conversation = chatHistory.slice(-6).map(item => ({ role: item.role, content: item.content }));
  const system = `أنت مدرس يشرح بالعربية المصرية بأسلوب حواري هادئ. أجب اعتمادًا على المقاطع الإنجليزية أدناه فقط. أجب عن السؤال ثم وضّح الفكرة ببساطة. تعامل مع «ليه؟» و«مش فاهم» باعتبارهما متابعة للسياق السابق. لا تخترع حقائق ولا تغيّر كلام المرجع. افصل بين ما يقوله المرجع وما هو تفسير. عند عدم كفاية النص قل: «المعلومة دي مش واضحة في الجزء اللي عندي من الكتاب». لا تقدم إرشادات تشغيل أو استهداف أو تنفيذ عسكرية. ضع أرقام المصادر [1] و[2] قرب كل معلومة.\n\nالمقاطع الأصلية:\n${sourceText}`;
  const response = await engine.chat.completions.create(requestOptions([
    { role: 'system', content: system },
    ...conversation,
    { role: 'user', content: question },
  ]));
  const text = response.choices?.[0]?.message?.content?.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
  return { text: text || 'النموذج ما أنتجش إجابة. أعد السؤال بصياغة أقصر.', hits };
}

let latestHits = [];
let answering = false;
async function sendQuestion() {
  const question = $('askInput').value.trim();
  if (!question || answering) return;
  $('askInput').value = '';
  addMessage(question, true);
  const waiting = addMessage('براجع المراجع المحلية...', false);
  waiting.classList.add('waiting');
  answering = true;
  $('askSend').disabled = true;
  try {
    await modelReady();
    const result = await answerQuestion(question, latestHits);
    waiting.remove();
    addMessage(result.text, false, result.hits);
    latestHits = result.hits;
    chatHistory.push({ role: 'user', content: question });
    chatHistory.push({ role: 'assistant', content: result.text });
  } catch (error) {
    waiting.remove();
    addMessage(error.message || 'فشل تشغيل المدرس المحلي.');
  } finally {
    answering = false;
    $('askSend').disabled = false;
  }
}
$('askSend').addEventListener('click', sendQuestion);
$('askInput').addEventListener('keydown', event => { if (event.key === 'Enter') sendQuestion(); });
$('modelStart').addEventListener('click', () => modelReady().catch(error => addMessage(error.message)));

async function extractPdf(file) {
  const data = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({ data }).promise;
  const pages = [];
  for (let number = 1; number <= pdf.numPages; number++) {
    const page = await pdf.getPage(number);
    const content = await page.getTextContent();
    pages.push({ number, text: content.items.map(item => item.str).join(' ') });
  }
  return pages;
}

async function importFile(file) {
  const extension = file.name.split('.').pop().toLowerCase();
  const ref = { id: crypto.randomUUID(), name: file.name, category: 'عام', active: true, type: extension, blob: file, pages: [] };
  if (extension === 'pdf') ref.pages = await extractPdf(file);
  else if (extension === 'txt') ref.pages = [{ number: 1, text: await file.text() }];
  else if (extension === 'json') {
    const data = JSON.parse(await file.text());
    ref.pages = Array.isArray(data.pages) ? data.pages.map((page, index) => ({ number: Number(page.number || index + 1), text: String(page.text || '') })) : [{ number: 1, text: JSON.stringify(data) }];
  } else throw new Error('الملف لازم يكون PDF أو TXT أو JSON.');
  await saveRef(ref);
  if (extension === 'pdf' && ref.pages.every(page => !page.text.trim())) return 'الملف اتضاف، لكن صفحاته مصوّرة ولا تحتوي نصًا قابلًا للبحث. يلزم OCR.';
  return 'اتضاف المرجع واتحفظ على الجهاز. تقدر تستخدمه حتى من غير إنترنت.';
}

function showReference(refId, page = 1) {
  allRefs().then(refs => {
    const ref = refs.find(item => item.id === refId);
    if (!ref?.blob || ref.type !== 'pdf') return;
    if (referenceUrl) URL.revokeObjectURL(referenceUrl);
    referenceUrl = URL.createObjectURL(ref.blob);
    $('bookTitle').textContent = ref.name;
    $('bookFrame').src = `${referenceUrl}#page=${page}`;
    $('referenceViewer').classList.remove('hidden');
    $('refsList').classList.add('hidden');
  });
}
$('backRefs').addEventListener('click', () => {
  $('bookFrame').src = 'about:blank';
  $('referenceViewer').classList.add('hidden');
  $('refsList').classList.remove('hidden');
});

async function renderRefs() {
  const host = $('refsList');
  host.replaceChildren();
  const refs = await allRefs();
  refs.sort((a, b) => a.name.localeCompare(b.name));
  for (const ref of refs) {
    const card = document.createElement('article');
    card.className = 'panel';
    const title = document.createElement('div');
    title.className = 'ref-name';
    title.textContent = ref.name;
    card.append(title);
    const meta = document.createElement('p');
    meta.className = 'ref-meta';
    meta.textContent = `${ref.active ? 'نشط' : 'موقوف'} · ${ref.pages.length} صفحة مفهرسة · محفوظ على هذا الجهاز`;
    card.append(meta);
    const actions = document.createElement('div');
    actions.className = 'row';
    if (ref.type === 'pdf') {
      const view = document.createElement('button');
      view.className = 'button secondary';
      view.textContent = 'فتح المرجع';
      view.addEventListener('click', () => showReference(ref.id));
      actions.append(view);
    }
    if (admin) {
      const toggle = document.createElement('button');
      toggle.className = 'button secondary';
      toggle.textContent = ref.active ? 'إيقاف' : 'تفعيل';
      toggle.addEventListener('click', async () => { ref.active = !ref.active; await saveRef(ref); renderRefs(); });
      const del = document.createElement('button');
      del.className = 'button danger';
      del.textContent = 'حذف';
      del.addEventListener('click', async () => {
        if (!confirm(`حذف ${ref.name} من هذا الجهاز؟`)) return;
        await removeRef(ref.id);
        renderRefs();
      });
      actions.append(toggle, del);
    }
    card.append(actions);
    host.append(card);
  }
  if (!refs.length) {
    const empty = document.createElement('p');
    empty.className = 'notice';
    empty.textContent = 'أضف مرجعًا من ملفات الجهاز. المراجع لا تُرفع للموقع.';
    host.append(empty);
  }
}

async function passwordRecord() { return getSetting('admin'); }
async function derivePassword(value, salt) {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(value), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 160000, hash: 'SHA-256' }, material, 256);
  return [...new Uint8Array(bits)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}
async function setPassword(value) {
  if (value.length < 8) throw new Error('الباسورد لازم يكون ٨ أحرف على الأقل.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  await saveSetting('admin', { salt: [...salt], digest: await derivePassword(value, salt) });
}
async function unlock() {
  if (admin) return;
  const stored = await passwordRecord();
  if (!stored) {
    const value = prompt('اختار باسورد المسؤول. ٨ أحرف على الأقل.');
    if (!value) return;
    try { await setPassword(value); admin = true; }
    catch (error) { alert(error.message); return; }
  } else {
    const value = prompt('باسورد المسؤول');
    if (!value) return;
    const digest = await derivePassword(value, new Uint8Array(stored.salt));
    if (digest !== stored.digest) { alert('الباسورد غير صحيح.'); return; }
    admin = true;
  }
  $('import').disabled = false;
  $('adminActions').classList.remove('hidden');
  $('adminStatus').textContent = 'وضع المسؤول مفتوح على هذا الجهاز';
  renderRefs();
}
$('unlock').addEventListener('click', unlock);
$('lockAdmin').addEventListener('click', () => {
  admin = false;
  $('import').disabled = true;
  $('adminActions').classList.add('hidden');
  $('adminStatus').textContent = 'استخدام المراجع مفتوح · الإدارة مقفولة';
  renderRefs();
});
$('changePass').addEventListener('click', async () => {
  if (!admin) return;
  const value = prompt('الباسورد الجديد. ٨ أحرف على الأقل.');
  if (!value) return;
  try { await setPassword(value); alert('تم تغيير الباسورد على هذا الجهاز.'); }
  catch (error) { alert(error.message); }
});
$('import').addEventListener('click', () => $('filePicker').click());
$('filePicker').addEventListener('change', async event => {
  const file = event.target.files?.[0];
  if (!file || !admin) return;
  try { alert(await importFile(file)); await renderRefs(); }
  catch (error) { alert(`تعذر إضافة الملف: ${error.message}`); }
  finally { event.target.value = ''; }
});

async function boot() {
  db = await openDb();
  $('chat').append(Object.assign(document.createElement('div'), {
    className: 'msg',
    textContent: 'اسألني بالراحة، وهنفهمها سوا. أول مرة هتشغّل المدرس هينزّل نموذجًا محليًا على الجهاز. بعد كده يقدر يشتغل من غير إنترنت.',
  }));
  if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  $('connection').textContent = navigator.onLine ? 'يعمل محليًا' : 'أوفلاين';
  window.addEventListener('online', () => { $('connection').textContent = 'يعمل محليًا'; });
  window.addEventListener('offline', () => { $('connection').textContent = 'أوفلاين'; });
  try { await navigator.serviceWorker?.register('./service-worker.js', { scope: './' }); } catch {}
  if (window.matchMedia('(display-mode: standalone)').matches || navigator.standalone) document.title = 'WL-1 Smart Instructor';
  else if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) $('installApp').classList.remove('hidden');
}
window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  installPrompt = event;
  $('installApp').classList.remove('hidden');
});
$('installApp').addEventListener('click', async () => {
  if (installPrompt) {
    await installPrompt.prompt();
    installPrompt = null;
    $('installApp').classList.add('hidden');
    return;
  }
  alert('على iPhone: افتح قائمة المشاركة في Safari ثم اختر إضافة إلى الشاشة الرئيسية. على الكمبيوتر: اختر تثبيت التطبيق من قائمة المتصفح.');
});
boot().catch(error => {
  $('modelStatus').textContent = `تعذر فتح التخزين المحلي: ${error.message}`;
});

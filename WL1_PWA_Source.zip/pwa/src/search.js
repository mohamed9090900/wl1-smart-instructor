function normalize(value) {
  return value.toLowerCase().normalize('NFKD').replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

const glossary = {
  'هيدروليك': ['hydraulic', 'hydraulics'], 'الهيدروليك': ['hydraulic', 'hydraulics'],
  'ضغط': ['pressure'], 'الضغط': ['pressure'], 'سائل': ['fluid'], 'السائل': ['fluid'],
  'مضخة': ['pump'], 'المضخة': ['pump'], 'خزان': ['reservoir', 'tank'], 'الخزان': ['reservoir', 'tank'],
  'صمام': ['valve'], 'الصمام': ['valve'], 'مشغل': ['actuator'], 'المشغل': ['actuator'],
  'مرشح': ['filter'], 'المرشح': ['filter'], 'تسريب': ['leak'], 'التسريب': ['leak'],
  'تدفق': ['flow'], 'التدفق': ['flow'], 'رجوع': ['return'], 'راجع': ['return'],
  'دائرة': ['circuit'], 'الدائرة': ['circuit'], 'مجمع': ['accumulator'], 'المجمع': ['accumulator'],
  'تنفيس': ['relief'], 'فرامل': ['brake'], 'الفرامل': ['brake'], 'عجلات': ['landing gear'],
  'اشرح': ['explain'], 'ليه': ['why'], 'وظيفة': ['function'], 'يعمل': ['operate', 'function'],
};

export function expandSearchTerms(query) {
  const normalized = normalize(query);
  const terms = new Set(normalized.split(/\s+/).filter(word => word.length > 2));
  for (const [arabic, english] of Object.entries(glossary)) {
    if (normalized.includes(normalize(arabic))) english.forEach(term => terms.add(term));
  }
  return [...terms];
}

function makeChunks(ref) {
  const chunks = [];
  for (const page of ref.pages || []) {
    const text = page.text.trim();
    for (let offset = 0; offset < text.length; offset += 740) {
      const chunk = text.slice(offset, offset + 900).trim();
      if (chunk) chunks.push({ refId: ref.id, name: ref.name, page: page.number, text: chunk });
    }
  }
  return chunks;
}

export function retrieve(query, refs, limit = 4) {
  const terms = expandSearchTerms(query);
  if (!terms.length) return [];
  const hits = [];
  for (const ref of refs.filter(item => item.active)) {
    for (const chunk of makeChunks(ref)) {
      const searchable = normalize(chunk.text);
      let score = 0;
      for (const term of terms) {
        const word = normalize(term);
        if (searchable.includes(word)) score += word.length > 6 ? 2 : 1;
      }
      if (score > 0) hits.push({ ...chunk, score });
    }
  }
  return hits.sort((a, b) => b.score - a.score).slice(0, limit);
}

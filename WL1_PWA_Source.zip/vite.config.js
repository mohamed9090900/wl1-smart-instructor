import { defineConfig } from 'vite';

export default defineConfig({
  root: 'pwa',
  base: './',
  publicDir: 'public',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    assetsDir: 'pwa-assets',
    target: 'es2022',
  },
});

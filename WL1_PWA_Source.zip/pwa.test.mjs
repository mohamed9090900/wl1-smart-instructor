import test from 'node:test';
import assert from 'node:assert/strict';
import { expandSearchTerms, retrieve } from './pwa/src/search.js';

const references = [
  {
    id: 'hydraulics', name: 'Hydraulic System', active: true,
    pages: [
      { number: 3, text: 'The hydraulic pump supplies pressurized fluid to the system.' },
      { number: 4, text: 'A reservoir stores hydraulic fluid.' },
    ],
  },
  { id: 'paused', name: 'Paused Reference', active: false, pages: [{ number: 1, text: 'The hydraulic pump is described here.' }] },
];

test('Arabic hydraulic terms expand to English search terms', () => {
  const terms = expandSearchTerms('إيه وظيفة المضخة الهيدروليكية؟');
  assert.ok(terms.includes('pump'));
  assert.ok(terms.includes('hydraulic'));
});

test('Arabic question retrieves the matching English page with its citation data', () => {
  const [hit] = retrieve('إيه وظيفة المضخة الهيدروليكية؟', references);
  assert.equal(hit.name, 'Hydraulic System');
  assert.equal(hit.page, 3);
  assert.match(hit.text, /pressurized fluid/i);
});

test('inactive references do not enter the teacher search', () => {
  const hits = retrieve('hydraulic pump', references);
  assert.ok(hits.every(hit => hit.refId !== 'paused'));
});
